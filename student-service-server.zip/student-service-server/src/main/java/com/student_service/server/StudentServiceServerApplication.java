package com.student_service.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class StudentServiceServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentServiceServerApplication.class, args);
		System.err.println("Eureka server is up and running");
	}

}
